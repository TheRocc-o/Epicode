USE ECOMMERCE;




---Visualizzare il nome del prodotto, il nome del produttore e il prezzo per tutti i prodotti di una determinata categoria (Fotocamera):
SELECT p.Nome, pr.NomeProduttore, p.Prezzo
FROM Prodotto  p
JOIN Produttore pr ON p.ProduttoreID = pr.ProduttoreID
JOIN Categoria c ON p.CategoriaID = c.CategoriaID
WHERE c.NomeCategoria = 'Fotocamera';


---Visualizzare il numero totale di prodotti venduti per ogni produttore:
SELECT pr.NomeProduttore, COUNT(*) AS NumeroProdottiVenduti
FROM Prodotto p
JOIN Produttore pr ON p.ProduttoreID = pr.ProduttoreID
JOIN DettaglioOrdine do ON p.ProductID = do.ProductID
GROUP BY pr.NomeProduttore;


---Visualizzare il nome e il prezzo dei prodotti ordinati da un utente specifico (1), ordinati per prezzo in ordine decrescente:
SELECT p.Nome, p.Prezzo
FROM Prodotto p
JOIN DettaglioOrdine do ON p.ProductID = do.ProductID
JOIN Ordine o ON do.OrderID = o.OrderID
WHERE o.UserID = 1
ORDER BY p.Prezzo DESC;


---Visualizzare i prodotti con una quantit� disponibile inferiore a 10, mostrando anche il nome del produttore:
SELECT p.Nome, pr.NomeProduttore
FROM Prodotto p
JOIN Produttore pr ON p.ProduttoreID = pr.ProduttoreID
WHERE p.Quantit�Disponibile < 10;


---Visualizzare il nome del prodotto, il prezzo e il numero totale di recensioni per ogni prodotto (con query innestata):
SELECT p.Nome, p.Prezzo, (
  SELECT COUNT(*)
  FROM Recensione r
  WHERE r.ProductID = p.ProductID
) AS NumeroRecensioni
FROM Prodotto p;



---Visualizzare tutti gli ordini effettuati da un determinato utente (1):
SELECT o.OrderID, o.DataOrdine,p.Prezzo, p.Nome AS NomeProdotto, d.Quantit�
FROM Ordine o
JOIN DettaglioOrdine d ON o.OrderID = d.OrderID
JOIN Prodotto p ON d.ProductID = p.ProductID
WHERE o.UserID = 1; 


---Visualizzare tutti i prodotti con le rispettive valutazioni e medie delle valutazioni
SELECT p.Nome AS NomeProdotto, r.Valutazione, AVG(r.Valutazione) AS MediaValutazione
FROM Prodotto p
LEFT JOIN Recensione r ON p.ProductID = r.ProductID
GROUP BY p.ProductID, p.Nome, r.Valutazione;


---Visualizzare i prodotti che hanno ricevuto una valutazione media superiore a 4:
SELECT p.Nome AS NomeProdotto, p.Prezzo, AVG(r.Valutazione) AS MediaValutazione
FROM Prodotto p
JOIN Recensione r ON p.ProductID = r.ProductID
GROUP BY p.ProductID, p.Nome, p.Prezzo
HAVING AVG(r.Valutazione) > 4


---Visualizzare tutti i prodotti in ordine di prezzo decrescente:
SELECT ProductID, Nome, Prezzo
FROM Prodotto
ORDER BY Prezzo DESC;


---Visualizzare gli ordini effettuati in un determinato intervallo di date:
SELECT o.OrderID, o.DataOrdine, o.Totale, u.Nome, u.Cognome
FROM Ordine o
JOIN Utente u ON o.UserID = u.UserID
WHERE o.DataOrdine BETWEEN '2022-05-01' AND '2022-08-31'; 



---Creare una view che ci permetta di avere una vista degli ordini dettagliata:
CREATE VIEW VistaOrdineDettagliata AS(
SELECT o.OrderID, o.DataOrdine, u.Nome, u.Cognome, p.Nome AS NomeProdotto, d.Quantit�, p.Prezzo, p.Prezzo * d.Quantit� AS TotaleOrdine
FROM Ordine o
JOIN Utente u ON o.UserID = u.UserID
JOIN DettaglioOrdine d ON o.OrderID = d.OrderID
JOIN Prodotto p ON d.ProductID = p.ProductID);


---Utilizzare la view precedentemente creata per calcolare il totale degli ordini per ogni utente:
SELECT Nome, Cognome, SUM(Quantit� * Prezzo) AS TotaleOrdini
FROM VistaOrdineDettagliata
GROUP BY Nome, Cognome
ORDER BY SUM(Quantit� * Prezzo) DESC;


---Utilizzare la view precedentemente creata per indicare il mese dell'ordine in base al nome e cognome dell'utente:
SELECT OrderID,Nome, Cognome, DATENAME(month, DataOrdine) AS MeseOrdine
FROM VistaOrdineDettagliata
WHERE Nome = 'Mario' AND Cognome = 'Rossi'












