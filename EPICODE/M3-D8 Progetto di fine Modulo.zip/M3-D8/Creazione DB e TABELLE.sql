CREATE DATABASE ECOMMERCE;
USE ECOMMERCE;



CREATE TABLE Utente (
			  UserID INT PRIMARY KEY,
			  Nome VARCHAR(50),
			  Cognome VARCHAR(50),
			  Email VARCHAR(100),
			  Password VARCHAR(100),
			  DataRegistrazione DATE);

CREATE TABLE Prodotto (
			  ProductID INT PRIMARY KEY,
			  Nome VARCHAR(100),
			  Descrizione TEXT,
			  Prezzo DECIMAL(10, 2),
			  Quantit�Disponibile INT,
			  ProduttoreID INT,
			  CategoriaID INT,
			  FOREIGN KEY (ProduttoreID) REFERENCES Produttore(ProduttoreID),
			  FOREIGN KEY (CategoriaID) REFERENCES Categoria(CategoriaID));

CREATE TABLE Ordine (
			  OrderID INT PRIMARY KEY,
			  UserID INT,
			  DataOrdine DATE,
			  Totale DECIMAL(10, 2),
			  FOREIGN KEY (UserID) REFERENCES Utente(UserID));

CREATE TABLE DettaglioOrdine (
			  OrderID INT,
			  ProductID INT,
			  Quantit� INT,
			  PRIMARY KEY (OrderID, ProductID),
			  FOREIGN KEY (OrderID) REFERENCES Ordine(OrderID),
			  FOREIGN KEY (ProductID) REFERENCES Prodotto(ProductID));

CREATE TABLE Recensione (
			  ReviewID INT PRIMARY KEY,
			  UserID INT,
			  ProductID INT,
			  Valutazione INT,
			  Commento TEXT,
			  FOREIGN KEY (UserID) REFERENCES Utente(UserID),
			  FOREIGN KEY (ProductID) REFERENCES Prodotto(ProductID));

CREATE TABLE Produttore (
			  ProduttoreID INT PRIMARY KEY,
			  NomeProduttore VARCHAR(100));

CREATE TABLE Categoria (
			  CategoriaID INT PRIMARY KEY,
			  NomeCategoria VARCHAR(100));



INSERT INTO Utente (UserID, Nome, Cognome, Email, Password, DataRegistrazione)
VALUES
  (1, 'Mario', 'Rossi', 'mario@email.com', 'password1', '2022-01-15'),
  (2, 'Laura', 'Bianchi', 'laura@email.com', 'password2', '2022-02-20'),
  (3, 'Marco', 'Verdi', 'marco@email.com', 'password3', '2022-03-10'),
  (4, 'Sara', 'Esposito', 'sara@email.com', 'password4', '2022-04-05'),
  (5, 'Luca', 'Russo', 'luca@email.com', 'password5', '2022-05-12'),
  (6, 'Giulia', 'Conti', 'giulia@email.com', 'password6', '2022-06-18');


INSERT INTO Prodotto (ProductID, Nome, Descrizione, Prezzo, Quantit�Disponibile, ProduttoreID, CategoriaID)
VALUES
  (1, 'iPhone 14', 'Smartphone Apple con fotocamera avanzata', 1029.99, 20, 1, 1),
  (2, 'Samsung Galaxy S23', 'Smartphone Samsung con display AMOLED', 1479.99, 15, 2, 1),
  (3, 'MacBook Pro', 'Laptop Apple con processore potente', 1399.99, 10, 1, 2),
  (4, 'Sony Bravia TV', 'Smart TV Sony con risoluzione 4K', 1499.99, 5, 3, 3),
  (5, 'Canon EOS R6', 'Fotocamera Canon con mirino elettronico', 2599.99, 8, 4, 4),
  (6, 'Bose QuietComfort', 'Cuffie wireless con cancellazione del rumore', 199.99, 12, 5, 5);


INSERT INTO Recensione (ReviewID, UserID, ProductID, Valutazione, Commento)
VALUES
(1,1,1,5, 'Ottimo Smartphone, fotocamera di qualit� e prestazioni veloci'),
(2,2,2,4, 'Buon telefono, display luminoso e batteria duratura'),
(3,3,3,4, 'Ottimo laptop, veloce e affidabile'),
(4,4,4,5, 'TV di alta qualit�, immagini nitide e colori vivaci'),
(5,5,5,5, 'Fotocamera professionale, risulatati eccellenti'),
(6,6,6,3, 'Cuffie comode, ma la qualit� del suono potrebbe essere migliore');

INSERT INTO Produttore (ProduttoreID, NomeProduttore)
VALUES
  (1, 'Apple'),
  (2, 'Samsung'),
  (3, 'Sony'),
  (4, 'Canon'),
  (5, 'Bose'),
  (6, 'LG');


INSERT INTO Categoria (CategoriaID, NomeCategoria)
VALUES
(1, 'Smartphone'),
(2, 'Laptop'),
(3, 'TV'),
(4, 'Fotocamera'),
(5, 'Cuffie');



INSERT INTO DettaglioOrdine (OrderID, ProductID, Quantit�)
VALUES
(1,1,1),
(1,4,2),
(2,3,1),
(3,5,1),
(4,2,1),
(5,6,1),
(6,1,1);



INSERT INTO Ordine (OrderID, UserID, DataOrdine, Totale)
VALUES
(1,1, '2022-05-01', 2059.98),
(2,2, '2022-06-10', 1399.99),
(3,3, '2022-07-15', 2599.99),
(4,4, '2022-08-20', 1479.99),
(5,5, '2022-09-23', 199.99),
(6,6, '2022-10-27', 1029.99);




INSERT INTO Recensione (ReviewID, UserID, ProductID, Valutazione, Commento)
VALUES
(7,1,4,3, 'TV di altissima qualit�, ottimo rapporto qualit� prezzo');


UPDATE Ordine
SET Totale = 2529.98
WHERE UserID = 1
